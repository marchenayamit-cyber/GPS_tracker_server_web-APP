package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var etTelefono: EditText
    private lateinit var etIp1: EditText
    private lateinit var etIp2: EditText

    private lateinit var rgModoEnvio: RadioGroup
    private lateinit var etPuerto: EditText
    private lateinit var btnEnviar: Button
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private lateinit var btnAutomatico: Button
    private var envioAutomaticoActivo = false

    private val handler = Handler(Looper.getMainLooper())
    private val INTERVALO_MS = 5000L

    private val runnableEnvio = object : Runnable {s
        override fun run() {
            val modoSms = rgModoEnvio.checkedRadioButtonId == R.id.rbSms
            val numero = etTelefono.text.toString().trim()

            if (!modoSms || numero.isNotEmpty()) {
                verificarPermisosYProceder()
            }

            handler.postDelayed(this, INTERVALO_MS)
        }
    }

    private val TIMEOUT_SOCKET_MS = 3000

    private val SENT = "SMS_SENT"
    private val DELIVERED = "SMS_DELIVERED"

    private val sentReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (resultCode) {
                Activity.RESULT_OK -> Toast.makeText(baseContext, "SMS enviado", Toast.LENGTH_SHORT).show()
                SmsManager.RESULT_ERROR_GENERIC_FAILURE -> Toast.makeText(baseContext, "Error: Fallo genérico", Toast.LENGTH_SHORT).show()
                SmsManager.RESULT_ERROR_NO_SERVICE -> Toast.makeText(baseContext, "Error: Sin servicio", Toast.LENGTH_SHORT).show()
                SmsManager.RESULT_ERROR_NULL_PDU -> Toast.makeText(baseContext, "Error: PDU nulo", Toast.LENGTH_SHORT).show()
                SmsManager.RESULT_ERROR_RADIO_OFF -> Toast.makeText(baseContext, "Error: Radio apagada", Toast.LENGTH_SHORT).show()
                else -> Toast.makeText(baseContext, "Error al enviar: $resultCode", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val deliveredReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (resultCode) {
                Activity.RESULT_OK -> Toast.makeText(baseContext, "SMS entregado", Toast.LENGTH_SHORT).show()
                Activity.RESULT_CANCELED -> Toast.makeText(baseContext, "SMS no entregado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val modoSms = rgModoEnvio.checkedRadioButtonId == R.id.rbSms

        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val sendSmsGranted = if (modoSms) {
            permissions[Manifest.permission.SEND_SMS] ?: false
        } else {
            true
        }

        if (fineLocationGranted && sendSmsGranted) {
            obtenerCoordenadasYEnviar()
        } else {
            Toast.makeText(
                this,
                "Se requieren los permisos necesarios para funcionar",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.RECEIVER_EXPORTED
        } else {
            0
        }
        ContextCompat.registerReceiver(this, sentReceiver, IntentFilter(SENT), flags)
        ContextCompat.registerReceiver(this, deliveredReceiver, IntentFilter(DELIVERED), flags)

        etTelefono = findViewById(R.id.etTelefono)
        etIp1 = findViewById(R.id.etIp1)
        etIp2 = findViewById(R.id.etIp2)
        etPuerto = findViewById(R.id.etPuerto)
        btnEnviar = findViewById(R.id.btnEnviar)
        rgModoEnvio = findViewById(R.id.rgModoEnvio)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        btnEnviar.setOnClickListener {
            val modoSms = rgModoEnvio.checkedRadioButtonId == R.id.rbSms

            if (modoSms) {
                val numero = etTelefono.text.toString().trim()
                if (numero.isEmpty()) {
                    etTelefono.error = "Ingresa un número válido"
                    return@setOnClickListener
                }
            }
            verificarPermisosYProceder()
        }

        btnAutomatico = findViewById(R.id.btnAutomatico)

        btnAutomatico.setOnClickListener {
            envioAutomaticoActivo = !envioAutomaticoActivo

            if (envioAutomaticoActivo) {
                btnAutomatico.text = "Detener envío automático"
                handler.post(runnableEnvio)
            } else {
                btnAutomatico.text = "Iniciar envío automático (5s)"
                handler.removeCallbacks(runnableEnvio)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnableEnvio)
        try {
            unregisterReceiver(sentReceiver)
            unregisterReceiver(deliveredReceiver)
        } catch (e: Exception) {
            // Ya desregistrados
        }
    }

    private fun verificarPermisosYProceder() {
        val modoSms = rgModoEnvio.checkedRadioButtonId == R.id.rbSms

        val permisoGps = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val permisoSms = if (modoSms) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
        } else {
            PackageManager.PERMISSION_GRANTED
        }

        if (permisoGps == PackageManager.PERMISSION_GRANTED && permisoSms == PackageManager.PERMISSION_GRANTED) {
            obtenerCoordenadasYEnviar()
        } else {
            val permisosNecesarios = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (modoSms) {
                permisosNecesarios.add(Manifest.permission.SEND_SMS)
            }

            requestPermissionsLauncher.launch(permisosNecesarios.toTypedArray())
        }
    }

    @SuppressLint("MissingPermission")
    private fun obtenerCoordenadasYEnviar() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            val numero = etTelefono.text.toString().trim()
            val modoSms = rgModoEnvio.checkedRadioButtonId == R.id.rbSms

            if (location != null) {
                val latitud = location.latitude
                val longitud = location.longitude

                // Formateo de la hora del satélite a formato local (ejemplo: "15:44:30")
                val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                val horaGpsLegible = sdf.format(Date(location.time))

                val mensaje = "Mi ubicacion: Lat $latitud, Long $longitud (Hora: $horaGpsLegible)"

                if (modoSms) {
                    enviarSMS(numero, mensaje)
                } else {
                    enviarPorRedAmbasIPs(latitud, longitud, horaGpsLegible)
                }
            } else {
                if (modoSms) {
                    Toast.makeText(this, "Buscando ubicación...", Toast.LENGTH_SHORT).show()
                    enviarSMS(numero, "Prueba de envío de SMS desde mi app.")
                } else {
                    Toast.makeText(this, "No se pudo obtener ubicación por red.", Toast.LENGTH_SHORT).show()
                }
            }
        }.addOnFailureListener {
            Toast.makeText(this, "Error de GPS: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun enviarSMS(numero: String, mensaje: String) {
        val numeroLimpio = numero.replace("[^0-9+]".toRegex(), "")

        val sentPI = PendingIntent.getBroadcast(this, 0, Intent(SENT), PendingIntent.FLAG_IMMUTABLE)
        val deliveredPI = PendingIntent.getBroadcast(this, 0, Intent(DELIVERED), PendingIntent.FLAG_IMMUTABLE)

        try {
            val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                this.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            Log.d("SMS_DEBUG", "Destino: $numeroLimpio | Msg: $mensaje")

            val partes = smsManager.divideMessage(mensaje)
            val sentIntents = ArrayList<PendingIntent>()
            val deliveryIntents = ArrayList<PendingIntent>()

            for (p in partes) {
                sentIntents.add(sentPI)
                deliveryIntents.add(deliveredPI)
            }

            smsManager.sendMultipartTextMessage(numeroLimpio, null, partes, sentIntents, deliveryIntents)

        } catch (e: Exception) {
            Toast.makeText(this, "Error crítico: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("SMS_DEBUG", "Error: ${e.message}", e)
        }
    }

    private fun enviarPorRedAmbasIPs(latitud: Double, longitud: Double, horaGps: String) {
        val puertoStr = etPuerto.text.toString().trim()
        val puerto = puertoStr.toIntOrNull()
        if (puerto == null || puerto !in 1..65535) {
            Toast.makeText(this, "Puerto inválido", Toast.LENGTH_SHORT).show()
            return
        }

        val ip1 = etIp1.text.toString().trim()
        val ip2 = etIp2.text.toString().trim()
        val ips = listOfNotNull(
            ip1.takeIf { it.isNotEmpty() },
            ip2.takeIf { it.isNotEmpty() }
        )

        if (ips.isEmpty()) {
            Toast.makeText(this, "Ingresa al menos una IP de destino", Toast.LENGTH_SHORT).show()
            return
        }

        // Trama enviando la hora del GPS formateada correctamente
        val trama = "TIPO=GPS,LAT=$latitud,LON=$longitud,TS=$horaGps\n"
        val payload = trama.toByteArray(Charsets.UTF_8)

        for (ip in ips) {
            enviarUDP(ip, puerto, payload)
        }
    }

    private fun enviarUDP(ip: String, puerto: Int, payload: ByteArray) {
        Thread {
            try {
                DatagramSocket().use { socket ->
                    socket.soTimeout = TIMEOUT_SOCKET_MS
                    val direccion = java.net.InetAddress.getByName(ip)
                    val paquete = DatagramPacket(payload, payload.size, direccion, puerto)
                    socket.send(paquete)
                }
                Log.d("NET_DEBUG", "UDP enviado a $ip:$puerto")
                runOnUiThread {
                    Toast.makeText(this, "UDP enviado a $ip:$puerto", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("NET_DEBUG", "Error UDP a $ip:$puerto -> ${e.message}", e)
                runOnUiThread {
                    Toast.makeText(this, "Error UDP a $ip: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}